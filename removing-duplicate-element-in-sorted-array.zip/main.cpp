/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    cout<<"Hello World";
int arr[]={1,1,2,2,3,4,4};
int n=sizeof(arr)/sizeof(arr[0]);
int j=0;
for(int i=0; i<n-1; i++)
{
    if(arr[i]!=arr[i+1])
    {
        arr[j]=arr[i];
        j++;
    }
}
arr[j]=arr[n-1];
for(int i=0; i<=j; i++)
{
    cout<<arr[i]<<" ";
}
    return 0;
}

