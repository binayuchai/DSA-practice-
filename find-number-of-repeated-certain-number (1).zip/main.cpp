/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
int first(int a[],int n,int x)
{
    for(int i=0; i<n; i++)
    {
        if(a[i] == x)
        {
            return i;
        }
    }
    
}
int last(int a[],int n,int x)
{
    
    for(int i=n-1; i>=0; i--)
    {
        if(a[i] == x)
        {
             return i;
        }
    }

}
int main()
{
    //cout<<"Hello World";
int arr[]={1,2,3,3,3,3,4};
int n=sizeof(arr)/sizeof(arr[0]);
int x=3;
int First = first(arr,n,x);
cout<<First;
int second =last(arr,n,x);
cout<<second;
int numOfOccurence = second - First + 1;
cout<<"number of occurence: "<<numOfOccurence<<endl;
    return 0;
}
