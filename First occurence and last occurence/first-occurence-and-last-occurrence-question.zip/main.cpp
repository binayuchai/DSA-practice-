/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

//this problem is solved by binay 

// -- Time complexity = O(n)  and Space complexity = O(1)
#include <iostream>
using namespace std;

int main()
{
   // printf("Hello World");
    int arr[]={1,3,5,5,5,5,67,123,165};
    int n=sizeof(arr)/sizeof(arr[0]);
    int x;
    cin>>x;
    int LastOccur;
    int FirstOccur;
    int count = -1;
    int flag = 0;
    for(int i=0; i<n; i++)
    {
        if(arr[i] == x)
        {
            LastOccur = i;
            count++;
            flag = 1;
        }
    }
    if(flag == 1)
    {
    FirstOccur = LastOccur - count; // Or we can do  count = 0; (FirstOccur = LastOccur - count + 1)
    cout<<"First Occurrence: "<<FirstOccur<<endl;
    cout<<"Last Occurrence: "<<LastOccur<<endl;
    }
    else
    {
        cout<<"No Occurrence"<<endl;
    }
    return 0;
}
