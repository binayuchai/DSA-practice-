/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include<climits>
using namespace std;

int main()
{
    //cout<<"Hello World";
int arr[]={5,3,-2,-1,8};
int maxSum = INT_MIN;
for(int i=0; i<5; i++)
{
    int sum=0;
    for(int j=i; j<5; j++)
    {
        sum+=arr[j];
    }
    maxSum = max(sum,maxSum);
}
cout<<maxSum;

    return 0;
}
