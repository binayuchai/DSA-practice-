/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
#include<algorithm>
using namespace std;

void display(int ar[],int n)
{
    for(int i=0; i<n; i++)
    {
        cout<<ar[i]<<" ";
    }
    cout<<endl;
}
int main()
{

   int arr[] = {5,3,2,8,1};
   int n = sizeof(arr)/sizeof(arr[0]);
   int k;
   cin>>k;         // money to buy items
   int ans =0;    // no of item that can be bought
   display(arr,n);
   sort(arr,arr+n);
   display(arr,n);
   if(n == 0 || k == 0)
   {
       cout<<0;
   }
   int i=0;
   while(i<n && k > arr[i])
   {
       ans++;
       k = k - arr[i];
       i++;
   }
   cout<<"No of item can be bought " <<ans;
    return 0;
}
