/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

void print(int a[],int n)
{
    for(int i=0; i<n ;i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;
}
void Swap(int *a,int *b)
{
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}
int Partition(int a[],int low,int high)
{
    int pivot = a[low];
    int i = low;
    int j = high;
    while(j>i){
    while(pivot >= a[i])
        {
            i++;
        }
    while(pivot < a[j])
    {
        j--;
    }
        if(i<j)
        Swap(&a[i],&a[j]);
   }
    Swap(&a[low],&a[j]);
    return j;
}
void QuickSort(int a[],int low,int high)
{
    if(low < high)
    {
    int pivot = Partition(a,low,high);
    QuickSort(a,low,pivot-1);
    QuickSort(a,pivot+1,high);
    }
}


int main()
{
   // cout<<"Hello World";
   int array[] = {3,5,1,0,34,6,2,8,5};
   int n = sizeof(array)/sizeof(array[0]);
   cout<<"Before sorting"<<endl;
   print(array,n);
   cout<<"after sorting using quick sort"<<endl;
   QuickSort(array,0,n-1);
   print(array,n);
   return 0;
}

