/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
//#include<algorithm>
using namespace std;

void insertionSort(int brr[],int m)
{
    for(int i=1; i<m; i++)
    {
        int key = brr[i];
        int j=i-1;
        while(j>=0 && key < brr[j])
        {
            brr[j+1] = brr[j];
            j--;
        }
        brr[j+1] = key;
    }
}
int main()
{
   // cout<<"Hello World";
int a[]={1,4,7,8,10};
int b[]={2,3,5};
int j=0;
int n=5;
int m=3;
for(int i=0; i<n; i++)
{
    if(a[i] > b[j])
    {
        swap(a[i],b[j]);
        insertionSort(b,m);
    }
}
for(int j=0; j<n; j++)
{
    cout<<a[j]<<" ";
}
cout<<endl;
for(int j=0; j<m; j++)
{
    cout<<b[j]<<" ";
}

    return 0;
}
