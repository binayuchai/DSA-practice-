/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
void print(int a[], int n)
{
    for(int i=0; i<n; i++)
    {
    cout<<a[i]<<" ";
}
}
void SortAndSearch(int a[],int n,int k)
{
    for(int i=0; i<n-1; i++)
    {
        for(int j=0; j<n-1-i; j++)
        {
            if(a[j]>a[j+1])
            {
                int temp;
                temp =a[j];
                a[j] = a[j+1];
                a[j+1] = temp;
            }
        }
    }
    print(a,n);
    cout<<"\nKth element is: "<<a[k-1]<<endl;
}
int main()
{
    //cout<<"Hello World";
    int n;
    cin>>n;
    int k;
    cin>>k;
    int a[n];
    for(int i=0; i<n; i++)
    {
        cin>>a[i];
    }
    print(a,n);
    cout<<k;
SortAndSearch(a,n,k);
    return 0;
}
