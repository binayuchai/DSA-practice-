/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    //cout<<"Hello World";
   int arr[]={1,2,3,4,4,4,5};
   int n= sizeof(arr)/sizeof(arr[0]);
   int last=-1;
   int first = -1;
   int x;
   cin>>x;
   for(int i=0; i<n; i++)
   {
       if(arr[i]==x)
       {
           first = i;
           break;
       }
   }
   for(int i=n-1; i>=0; i--)
   {
       if(arr[i] == x)
       {
           last = i;
           break;
       }
   }
   cout<<"First Occurence: "<<first<<endl<<"Last Occurence: "<<last<<endl;
   return 0;
}
