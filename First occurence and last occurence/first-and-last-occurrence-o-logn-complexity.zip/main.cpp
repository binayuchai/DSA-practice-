/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
// finding first occurrence
int first_occur(int arr[],int n, int x,int low,int high)
{
    if(low<=high)
    {
        int mid = (low + high)/2;
        if((mid == 0 || arr[mid-1] < x) && (arr[mid] == x))
        {
            return mid;
        }
        else if(arr[mid] < x)
        {
            return first_occur(arr,n,x,mid+1,high);
        }
        else
        {
            return first_occur(arr,n,x,low,mid-1);
        }
    }
}

// to find last occurrence 
int last_occur(int arr[],int n, int x,int low,int high)
{
    if(low<=high)
    {
        int mid = (low + high)/2;
        if((mid == n-1 || arr[mid+1] > x) && (arr[mid] == x))
        {
            return mid;
        }
        else if(arr[mid] > x)
        {
            return last_occur(arr,n,x,low,mid-1);
        }
        else
        {
            return last_occur(arr,n,x,mid+1,high);
        }
    }
}
int main()
{
    //printf("Hello World");
    int arr[]={1,1,2,2,2,3,4};
    int n = sizeof(arr)/sizeof(arr[0]);
    int x = 2;
    cout<<"First occurrence = "<<first_occur(arr,n,x,0,n-1)<<endl;
    cout<<"Last occurrence = "<<last_occur(arr,n,x,0,n-1)<<endl;
    return 0;
}
