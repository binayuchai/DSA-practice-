/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.*/

// Subarray with given sum 

#include <iostream>
#include<climits>
using namespace std;
void hope(int arr[],int n)
{
    int s=12;
for(int i=0; i<5; i++)
{
    int sum=0;
    for(int j=i; j<5; j++)
    {
        sum+=arr[j];
        if(s == sum)
        {
            cout<<(i+1)<<" "<<(j+1); // position of array 
            return;
        }
    }
   // maxSum = max(sum,maxSum);
}
}
int main()
{
    //cout<<"Hello World";
int arr[]={1,2,3,7,5};
//int maxSum = INT_MIN;
hope(arr,5);
//cout<<maxSum;

    return 0;
}


