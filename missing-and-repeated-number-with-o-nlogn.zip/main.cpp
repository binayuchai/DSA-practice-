/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include<algorithm>
using namespace std;
void repeated_num(int arr[],int n)
{
    sort(arr,arr+n);  // O(nlogn)
    bool flag = false;
    int repeatNUm;
    for(int i=0; i<n; i++)            // O(n)
    {
        if(arr[i] == arr[i+1])
        {
            repeatNUm = arr[i];
            flag = true;
        }
    }
    if(flag)
    {
        cout<<"Repeated number: "<<repeatNUm<<endl;
    }
    else
    {
        cout<<"No repeatation"<<endl;
    }
    int num = arr[n-1];
    int total = ((num*(num+1))/2 + repeatNUm); 
    for(int i=0; i<n; i++) // O(n)
    {
        total-=arr[i];
    }
    cout<<"Missing number: "<<total;
}
int main()
{
    //cout<<"Hello World";
    int arr[]={1,1,3,4,5};
    int n=sizeof(arr)/sizeof(arr[0]);
    repeated_num(arr,n);
   // cout<<endl;
  //  missing_num(arr,n);
    return 0;
}
