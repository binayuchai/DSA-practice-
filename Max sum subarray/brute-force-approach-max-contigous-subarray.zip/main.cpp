/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include<climits>
using namespace std;

void print(int a[],int n)
{
    for(int i=0; i<n; i++)
    {
    cout<<a[i]<<" ";
    }
}
void SubArray(int a[],int n)
{
    int maxSum=INT_MIN;
   // int sum;
    for(int i=0; i<n; i++)
    {
        for(int j=i; j<n; j++)
        {
            int sum=0;
            for(int k=i; k<=j; k++)
            {
                sum+=a[k];
            }
            if(sum>maxSum)
            {
                maxSum = sum;
            }
            
        }
    }
    cout<<maxSum;
}
int main()
{
    //cout<<"Hello World";
int ar[]={-1,2,-3,4,5};
SubArray(ar,5);
    return 0;
}

