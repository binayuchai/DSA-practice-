/******************************************************************************

Welcome to GDB Online.
GDB online is *an online compiler *and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, *assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run *and Debug online from *anywhere in world.

************************************************************************/
#include<iostream>
#include<vector>
using namespace std;
int swap(long long *a,long long *b)
{
    long long temp;
    temp = *a;
    *a= *b;
    *b = temp;
}
int main()
{
    long long arr[]={35,56};
int n=2;
int k=3;
    for(int i=0; i<n; i=i+k)
    {
        int left=i;
        int right = min(i+k-1,n-1);
        while(left<right)
        {
            swap(arr[left++],arr[right--]);
        }
    }
    for(int i=0; i<n; i++)
    {
        cout<<arr[i]<<" ";
    }
    return 0;
}