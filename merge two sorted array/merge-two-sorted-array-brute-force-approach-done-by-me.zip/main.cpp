/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    //cout<<"Hello World";
    int a[]={1,4,6,7,8};
    int b[]={2,3,5};
    int n=sizeof(a)/sizeof(a[0]);
    int m=sizeof(b)/sizeof(b[0]);
    // third array to store merged element where Space Complexity is O(n+m)
    int temp[n+m];
    // storing the element after comparing greatest number among two array
    int i=0;
    int j=0;
    int k=0;
    while(i<n && j<m) // O(n*m)
    {
        if(a[i] < b[j])
        {
            temp[k++] = a[i];
            i++;
        }
        else
        {
            temp[k++] = b[j];
            j++;
        }
    }
    // if one of two array is exhausted first then we should print rest of element of remaining array 
    
    while(i<n)
    {
        temp[k++] = a[i++];
    }
    while(j<m)
    {
        temp[k++] = b[j++];
    }
    for(int i=0; i < n+m; i++)
    {
        cout<<temp[i]<<" ";
    }

    return 0;
}

