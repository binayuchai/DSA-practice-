/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    int arr[]={-1,-2,4,5,-6,3};
    int n=sizeof(arr)/sizeof(arr[0]);
    int max_so_far = 0;
    int max_ending_here = 0;
    for(int i=0; i<n; i++)
    {
        max_ending_here = max_ending_here + arr[i];
        if(max_ending_here < 0)
        {
            max_ending_here = 0;
        }
        if(max_ending_here > max_so_far)
        {
            max_so_far = max_ending_here;
        }
    }
    cout<<max_so_far;
    return 0;
}
